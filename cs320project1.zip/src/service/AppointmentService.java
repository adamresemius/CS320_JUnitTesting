package service;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    Map<String, String> appointments;

    public AppointmentService() {
        appointments = new HashMap<>();
    }

    public void addAppointment(String appointmentId, String appointmentDetails) {
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Duplicate appointment ID");
        }
        appointments.put(appointmentId, appointmentDetails);
    }

    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment not found");
        }
        appointments.remove(appointmentId);
    }
}
