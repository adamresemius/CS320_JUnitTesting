package service;

import java.util.Calendar;
import java.util.Date;

public class Appointment{
    private String appointmentID, appointmentDescription;
    private Date appointmentDate;
 
    public Appointment(String appointmentID, Date appointmentDate, String appointmentDescription) {
        if (appointmentID == null || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Appointment ID cannot be null or exceed 10 characters.");
        }
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date cannot be null.");
        }
        Calendar now = Calendar.getInstance();
        Calendar appointment = Calendar.getInstance();
        appointment.setTime(appointmentDate);
        if (appointment.before(now)) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }
        if (appointmentDescription == null || appointmentDescription.length() > 50){
            throw new IllegalArgumentException("Appointment Description cannot be longer than 50 characters or null.");
        }
        this.appointmentID = appointmentID;
        this.appointmentDate = appointmentDate;
        this.appointmentDescription = appointmentDescription;
    }
 
    public String getAppointmentID() {
        return appointmentID;
    }
 
    public Date getAppointmentDate() {
        return appointmentDate;
    }
 
    public String getAppointmentDescription() {
        return appointmentDescription;
    }
    public void setAppointmentID(String appointmentID) {
		this.appointmentID = appointmentID;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public void setAppointmentDescription(String appointmentDescription) {
		this.appointmentDescription = appointmentDescription;
	}
}
