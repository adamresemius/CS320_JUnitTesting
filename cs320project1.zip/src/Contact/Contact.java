package Contact;
import java.lang.IllegalArgumentException ;

public class Contact{
    private String contact_ID, firstName, lastName, phoneNumber, contactAddress;

    public Contact(String contact_ID, String firstName, String lastName, String phoneNumber, String contactAddress) {
        try {
            if (contact_ID == null || contact_ID.length() > 10) {
                throw new IllegalArgumentException("Contact ID cannot be longer than 10 characters or null.");
            }
            if (firstName == null || firstName.length() > 10) {
                throw new IllegalArgumentException("First Name cannot be longer than 10 characters or null.");
            }
            if (phoneNumber == null || phoneNumber.length() != 10) {
                throw new IllegalArgumentException("Phone number must be exactly 10 characters and cannot be null.");
            }
            if (lastName == null || lastName.length() > 10) {
                throw new IllegalArgumentException("Last Name cannot be longer than 10 characters or null.");
            }
            if (contactAddress == null || contactAddress.length() > 30) {
                throw new IllegalArgumentException("Address cannot be longer than 30 characters or null.");
            }
            for(int i = 0; i < phoneNumber.length(); i++) {
                if(!Character.isDigit(phoneNumber.charAt(i))) {
                    throw new IllegalArgumentException("Phone number must include only digits.");
                }
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
            return;
        }
        this.contact_ID = contact_ID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.contactAddress = contactAddress;
    }

    public String getContact_ID() {
        return contact_ID;
    }

    public void setContact_ID(String contact_ID) {
        this.contact_ID = contact_ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getContactAddress() {
        return contactAddress;
    }

    public void setContactAddress(String contactAddress) {
        this.contactAddress = contactAddress;
    }
}

