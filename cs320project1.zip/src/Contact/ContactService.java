package Contact;
import java.util.HashMap;
import java.lang.IllegalArgumentException ;

class ContactService {
    public HashMap<String, Contact> contacts;

    public ContactService() {
        contacts = new HashMap<String, Contact>();
    }
    
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContact_ID())) {
            throw new IllegalArgumentException("Contact ID already exists. Please use a different ID.");
        }
        contacts.put(contact.getContact_ID(), contact);
    }

    public void deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID does not exist. Please enter a valid ID.");
        }
        contacts.remove(contactID);
    }

    public void updateContact(String contactID, String firstName, String lastName, String phoneNumber, String contactAddress) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID does not exist. Please enter a valid ID.");
        }
        Contact contact = contacts.get(contactID);
        contact.setFirstName(firstName);
        contact.setLastName(lastName);
        contact.setPhoneNumber(phoneNumber);
        contact.setContactAddress(contactAddress);
    }
}