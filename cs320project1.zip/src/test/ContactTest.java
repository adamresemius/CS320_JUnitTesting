package test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;
import Contact.Contact;

public class ContactTest {
//contact ID tests
	@Test
	void testContactID_Valid() {
	Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
	assertEquals("1234567890", contact.getContact_ID());
	}

	@Test(expected = IllegalArgumentException.class)
	void testContactID_TooLong() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
	    });
	}

	@Test(expected = IllegalArgumentException.class)
	void testContactID_Null() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact(null, "John", "Doe", "1234567890", "123 Main St");
	    });
	}
//First name tests
	@Test
	void testFirstName_Valid() {
	    Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
	    assertEquals("John", contact.getFirstName());
	}

	@Test(expected = IllegalArgumentException.class)
	void testFirstName_TooLong() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567890", "JohnDoeJohnDoe", "Doe", "1234567890", "123 Main St");
	    });
	}

	@Test(expected = IllegalArgumentException.class)
	void testFirstName_Null() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567890", null, "Doe", "1234567890", "123 Main St");
	    });
	}
//Last name tests
	@Test
	void testLastName_Valid() {
	    Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
	    assertEquals("Doe", contact.getLastName());
	}

	@Test(expected = IllegalArgumentException.class)
	void testLastName_TooLong() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567890", "John", "DoeDoeDoeDoe", "1234567890", "123 Main St");
	    });
	}

	@Test(expected = IllegalArgumentException.class)
	void testLastName_Null() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567890", "John", null, "1234567890", "123 Main St");
	    });
	}
//Phone number tests
	   @Test(expected = IllegalArgumentException.class)
	    void testPhoneNumberTooLong() {
	        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
	                () -> new Contact("1234567890", "John", "Doe", "12345678901", "123 Main St"));
	        assertEquals("Phone number must be exactly 10 characters and cannot be null.", exception.getMessage());
	    }

	    @Test(expected = IllegalArgumentException.class)
	    void testPhoneNumberTooShort() {
	        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
	                () -> new Contact("1234567890", "John", "Doe", "12345678", "123 Main St"));
	        assertEquals("Phone number must be exactly 10 characters and cannot be null.", exception.getMessage());
	    }

	    @Test(expected = IllegalArgumentException.class)
	    void testPhoneNumberNotAllDigits() {
	        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
	                () -> new Contact("1234567890", "John", "Doe", "123456789a", "123 Main St"));
	        assertEquals("Phone number must include only digits.", exception.getMessage());
	    }
	   @Test
	    void testValidPhoneNumber() {
		   Contact c = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
	        assertEquals("1234567890", c.getPhoneNumber());
	    }
//Address Tests
	    @Test(expected = IllegalArgumentException.class)
	    void testAddressTooLong() {
	        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
	                () -> new Contact("1234567890", "John", "Doe", "1234567890", "123 Main Street, Suite 100, Long City, USA"));
	        assertEquals("Address cannot be longer than 30 characters or null.", exception.getMessage());
	    }

	    @Test(expected = IllegalArgumentException.class)
	    void testAddressNull() {
	        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
	                () -> new Contact("1234567890", "John", "Doe", "1234567890", null));
	        assertEquals("Address cannot be longer than 30 characters or null.", exception.getMessage());
	    }

	    @Test
	    void testValidAddress() {
	        Contact c = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
	        assertEquals("123 Main St", c.getContactAddress());
	    }
	}
	   