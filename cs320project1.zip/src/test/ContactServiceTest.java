package test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;
import ContactService.ContactService;

class ContactServiceTests {
    ContactService contactService = new ContactService();
    Contact contact = new Contact("1", "John", "Doe", "555-555-5555", "123 Main St");
    
    @Test
    void testAddContact() {
        contactService.addContact(contact);
        assertTrue(contactService.contacts.containsKey("1"));
    }
    
    @Test
    void testAddContact_duplicateID() {
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact);
        });
    }
    
    @Test
    void testDeleteContact() {
        contactService.addContact(contact);
        contactService.deleteContact("1");
        assertFalse(contactService.contacts.containsKey("1"));
    }
    
    @Test
    void testDeleteContact_invalidID() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("1");
        });
    }
    
    @Test
    void testUpdateContact() {
        contactService.addContact(contact);
        contactService.updateContact("1", "Jane", "Smith", "555-555-5556", "456 Elm St");
        Contact updatedContact = contactService.contacts.get("1");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("555-555-5556", updatedContact.getPhoneNumber());
        assertEquals("456 Elm St", updatedContact.getContactAddress());
    }
    
    @Test
    void testUpdateContact_invalidID() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("1", "Jane", "Smith", "555-555-5556", "456 Elm St");
        });
    }
}