package test;


import org.junit.Before;
import org.junit.Test;

import service.AppointmentService;

import static org.junit.Assert.*;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @Before
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        appointmentService.addAppointment("1", new Date(), "Doctor's appointment");
        assertEquals("Doctor's appointment", appointmentService.getAppointment("1").getAppointmentDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddAppointment_duplicateId() {
        appointmentService.addAppointment("1", new Date(), "Doctor's appointment");
        appointmentService.addAppointment("1", new Date(), "Dentist's appointment");
    }

    @Test
    public void testDeleteAppointment() {
        appointmentService.addAppointment("1", new Date(), "Doctor's appointment");
        appointmentService.deleteAppointment("1");
        assertFalse(appointmentService.appointments.containsKey("1"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDeleteAppointment_notFound() {
        appointmentService.deleteAppointment("1");
    }
}
