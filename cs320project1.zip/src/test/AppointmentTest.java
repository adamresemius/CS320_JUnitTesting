package test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.Test;

import service.Appointment;

public class AppointmentTest {
	// appointmentID tests:
	@Test
	public void appointmentID_IsValid(){
		Appointment appointment = new Appointment("1234567890", new Date(), "Appointment Description");
		assertEquals("1234567890", appointment.getAppointmentID());
	}

	@Test
	public void appointmentID_TooLong(){
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678901", new Date(), "Appointment Description");
		});
	}

	@Test
	public void appointmentID_IsNull(){
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, new Date(), "Appointment Description");
		});
	}

	// appointmentDate tests:
	@Test
	public void appointmentDate_IsValid(){
		Calendar now = Calendar.getInstance();
		now.add(Calendar.DATE, 1);
		Date tomorrow = now.getTime();
		Appointment appointment = new Appointment("1234567890", tomorrow, "Appointment Description");
		assertEquals(tomorrow, appointment.getAppointmentDate());
	}

	@Test
	public void appointmentDate_IsInThePast(){
		Calendar now = Calendar.getInstance();
		now.add(Calendar.DATE, -1);
		Date yesterday = now.getTime();
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", yesterday, "Appointment Description");
		});
	}

	@Test
	public void appointmentDate_IsNull(){
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", null, "Appointment Description");
		});
	}

	// appointmentDescription tests:
	@Test
	public void appointmentDescription_IsValid(){
		Appointment appointment = new Appointment("1234567890", new Date(), "Appointment Description");
		assertEquals("Appointment Description", appointment.getAppointmentDescription());
	}

	@Test
	public void appointmentDescription_TooLong(){
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", new Date(), "Sassy squirrel steals snacks, causes chaos in the park.");
		});
	}

	@Test
	public void appointmentDescription_IsNull(){
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", new Date(), null);
		});
	}
}
