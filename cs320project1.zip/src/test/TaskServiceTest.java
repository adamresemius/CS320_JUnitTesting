package test;
import org.junit.jupiter.api.Test;

import task.Task;
import task.TaskService;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService taskService = new TaskService();
    private Task task = new Task("123", "Test Task", "This is a test task");

    @Test
    public void addTask_Valid() {
        taskService.addTask(task);
        assertTrue(taskService.tasks.containsKey("123"));
    }

    @Test
    public void addTask_Duplicate() {
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task));
    }

    @Test
    public void deleteTask_Valid() {
        taskService.addTask(task);
        taskService.deleteTask("123");
        assertFalse(taskService.tasks.containsKey("123"));
    }

    @Test
    public void deleteTask_Invalid() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("123"));
    }

    @Test
    public void updateTask_Valid() {
        taskService.addTask(task);
        taskService.updateTask("123", "Updated Task", "This is an updated task");
        assertEquals("Updated Task", taskService.tasks.get("123").getTaskName());
        assertEquals("This is an updated task", taskService.tasks.get("123").getTaskDescription());
    }

    @Test
    public void updateTask_Invalid() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTask("123", "Updated Task", "This is an updated task"));
    }

@Test
public void updateTask_NullName() {
    taskService.addTask(task);
    assertThrows(IllegalArgumentException.class, () -> taskService.updateTask("123", null, "This is an updated task"));
}

@Test
public void updateTask_NullDescription() {
    taskService.addTask(task);
    assertThrows(IllegalArgumentException.class, () -> taskService.updateTask("123", "Updated Task", null));
}
}
