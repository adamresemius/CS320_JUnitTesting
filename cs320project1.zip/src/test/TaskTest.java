package test;
import java.lang.IllegalArgumentException;
import org.junit.jupiter.api.Test;
import task.Task;

import static org.junit.jupiter.api.Assertions.*;
public class TaskTest {

    // taskID tests:
	@Test
	public void taskID_IsValid(){
	    Task task = new Task("1234567890", "Task Name", "This is a description of Task");
	    assertEquals("1234567890", task.getTaskID());
	}

    @Test
    public void taskID_TooLong(){
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "This is a description of Task");
        });
    }

    @Test
    public void taskID_IsNull(){
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "This is a description of Task");
        });
    }

    // taskName tests:
    @Test 
    public void taskName_IsValid(){
        Task task = new Task("1234567890", "Task Name", "This is a description of Task");
        assertEquals("Task Name", task.getTaskName());
    }

    @Test
    public void taskName_TooLong(){
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "#################", "This is a description of Task");
        });
    }

    @Test
    public void taskName_IsNull(){
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", null, "This is a description of Task");
        });
    }

    // taskDescription tests:
    @Test 
    public void taskDescription_IsValid(){
        Task task = new Task("1234567890", "Task Name", "This is a description");
        assertEquals("This is a description", task.getTaskDescription());
    }

    @Test
    public void taskDescription_TooLong(){
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Task Name", "Sassy squirrel steals snacks, causes chaos in the park.");
        });
    }

    @Test
    public void taskDescription_IsNull(){
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Task Name", null);
        });
    }
}