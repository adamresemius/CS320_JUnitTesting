package task;
import java.lang.IllegalArgumentException;

public class Task {
    //initializing Strings that will be used 
    String taskID, taskName, taskDescription;

    // creating constructor for this class
    public Task(String taskID, String taskName, String taskDescription){

        //creating parameters for the Strings using a try statement
        try {
            if (taskID == null || taskID.length() > 10){
                throw new IllegalArgumentException("Task ID cannot be longer than 10 characters or null.");
            }
            if (taskName == null || taskName.length() > 30){
                throw new IllegalArgumentException("Task Name cannot be longer than 20 characters or null.");
            }
            if (taskDescription == null || taskDescription.length() > 50){
                throw new IllegalArgumentException("Task Description cannot be longer than 50 characters or null.");
            }
        }
        catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
            return;
        }
        this.taskID = taskID;
        this.taskName = taskName;
        this.taskDescription = taskDescription;


        
    }

    //creating getter and setter methods for taskID, taskName, and taskDescription 
    public String getTaskID() {
        return taskID;
    }
    public String getTaskName() {
        return taskName;
    }
    public String getTaskDescription() {
        return taskDescription;
    }
    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }
    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }
    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }
 }