package task;
import java.lang.IllegalArgumentException;
import java.util.HashMap;

public class TaskService{

    //initializing hashmap to store tasks
    public HashMap <String, Task> tasks;

    //creating constructor and loading it with contents from the class task
    public TaskService() {
        tasks = new HashMap<String, Task>();
    }

    //creating method to add a task when a provided a unique ID
    public void addTask(Task task){
        if (tasks.containsKey(task.getTaskID())){
            throw new IllegalArgumentException("This task ID is already in use. Please provide a unique task ID");
        }
        tasks.put(task.getTaskID(), task);
    }

    //creating method to delete tasks when ID is provided
    public void deleteTask(String taskID){
        if (!tasks.containsKey(taskID)){
            throw new IllegalArgumentException("This task does not exist, Please enter a vaid Task ID.");
        }
        tasks.remove(taskID);
    }

    //creating method to update the taskName and taskDescription provided the taskID 
    public void updateTask(String taskID, String taskName, String taskDescription){
        if (!tasks.containsKey(taskID)){
            throw new IllegalArgumentException("Task ID not found. Please enter a valid Task ID.");
        }
        Task task = tasks.get(taskID);
        task.setTaskName(taskName);
        task.setTaskDescription(taskDescription);
    }

} 